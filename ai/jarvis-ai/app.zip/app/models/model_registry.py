AVAILABLE_MODELS = {

    "skeleton":{

        "type":"test",

        "gpu_required":False

    }

}
