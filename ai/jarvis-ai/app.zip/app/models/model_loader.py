from llama_cpp import Llama
import os

MODEL = None

def load_model(name):

    global MODEL

    MODEL = Llama(

        model_path=os.getenv("MODEL_PATH","/models/llama3/model.gguf"),

        n_gpu_layers=int(os.getenv("LLM_GPU_LAYERS",999)),

        n_ctx=int(os.getenv("LLM_CTX",8192)),

        n_threads=int(os.getenv("LLM_THREADS",12)),

        n_batch=int(os.getenv("LLM_BATCH",512)),

        verbose=True
    )

def model_status():

    if MODEL is None:

        return {

            "loaded":False

        }

    return {

        "name":"llama3",

        "loaded":True,

        "gpu_layers":int(os.getenv("LLM_GPU_LAYERS",999)),

        "ctx":int(os.getenv("LLM_CTX",8192)),
        
        "threads": int(os.getenv("LLM_THREADS",12)),
        
        "batch": int(os.getenv("LLM_BATCH",512))

    }

def get_model():

    def wrapped_model(prompt,max_tokens=256,temperature=0.7):

        if MODEL is None:

            return {

                "text":"",
                "tokens":0

            }

        raw = MODEL(

            prompt,

            max_tokens=max_tokens,

            temperature=temperature

        )

        text = raw["choices"][0]["text"]

        tokens = 0

        if "usage" in raw:

            tokens = raw["usage"].get("completion_tokens",0)

        if tokens == 0:

            tokens = max_tokens

        return {

            "text":text,
            "tokens":tokens

        }

    return wrapped_model
