from models.model_loader import model_status


def list_models():

    status = model_status()

    return {

        "loaded_models": status,

        "count": 1 if status["loaded"] else 0

    }
